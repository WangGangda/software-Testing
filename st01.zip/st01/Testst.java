package st2020;

import static org.junit.Assert.assertEquals;
import java.util.Arrays;
import java.util.Collection;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
@RunWith(Parameterized.class)
public class Testst {
		private int value;
		private boolean result;
		private St01 st;
		public Testst(int v,boolean num) {
			value=v;
			result=num;
		}
		@Before
		public void setUp() {
			st=new St01();
		}
		@Test
		public void testst() {
			assertEquals(result,st.isSucceed(value));
		}
		@Parameters
		public static Collection getData(){
			return Arrays.asList(new Object[][]{
							  {1,true},
							  {2,true},
							  {3,true},
							  {4,false},
							  {5,true},
							  {6,true},
							  {7,true},
							  {8,true},
							  {9,false},
							  {10,true},
							  {15,true},
							  {20,true},
							  {25,true},
							  {30,true},
							  {35,true},
							  {40,true},
							  {45,false},
							  {50,true},
							  {66,true},
							  {70,true},
							  {75,true},
							  {84,false},
							  {85,true},
							  {93,true},
							  {94,false},
							  {100,false}
							  
			
			});
			
		}
}
